# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 12:43:13 2019

@author: emithun
"""
from pylab import *

# Definerar funksjonen hello
def hello():
    print("Hello WOrld!")

hello() # Kallar på funksjonen hello, og utfører koden som er definert for hello

# Definerer funksjonen f, som tar inn eit argument som den skal bruke i koden
def f(a):
    #print(x**2)
    return a**2+2*a-1 # Returnerer verdi sånn at me kan lagre den og jobbe vidare med den.

x=linspace(-5,5,100) # Lagar eit array med 100 tall
y=f(x) # Kjører funksjonen f med alle element i arrayet x
plot(x,y) # Lagar eit plot av arrayet x og y.
grid(True) # Legger på rutenett på grafikkfeltet