# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 11:14:09 2019

@author: emithun
"""
# Lastar inn bibliotek for plot og linspace
from pylab import *

"""
Her er det berre å prøve seg fram ved å endre på tekst for å sjå endringar.
*r gjer at det blir vist punktvis og at dei blir røde
"""
x=linspace(-5,5,11)
y=x**2
plot(x,y,"*r")
legend(["Navn på graf"])
xlabel("x-verdier")
ylabel("y-verdier")
title("Plot av x^2")
grid("true")
axhline(y=0,color="k")
axvline(x=0,color="k")






