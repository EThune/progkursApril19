# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 12:51:58 2019

@author: emithun
"""

import random as r # Bibliotek for metodar/funksjonar for tilfeldige tal

h=r.randint(1,100) # Tilfeldig heiltal f.o.m. 1 t.o.m.100

inp=int(input("Kva tal gjettar du på?")) # Leser inn tal frå brukaren

# Funksjon som sjekkar om to tal er like og skriv ut passande tilbakemelding
def lik(a,b):
    if a==b:
        print("Gratulerer")
        return True
    elif a<b:
        print("Du gjetta for høgt")
        return False
    else:
        print("Du har gjetta for lågt")
        return False

"""
Så lenge brukaren ikkje har tippa likt tal som det hemmelege talet,
så vil programmet spørre etter nytt tal.
"""     
while not lik(h,inp):
    inp=int(input("Kva tal gjettar du på?")) # Les inn nytt tal frå brukaren