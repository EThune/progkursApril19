# -*- coding: utf-8 -*-
"""
Created on Mon Apr 15 20:17:40 2019

@author: emithun
"""

print("Utskrift frå for-løkka:")
for i in range(1,11):
    print(i**2)
    
print("Utskrift frå while-løkka:")
a=10
while a>0:
    print(a**2)
    a=a-1