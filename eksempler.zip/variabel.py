# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 10:00:05 2019

@author: emithun
"""

# Deklarerer variabel med verdi 5
a=5
a=a*2 # Ganger verdien til a med 2, a=10
print("Tallet er" , a) # Skriver ut tekst og verdi av variabel a

b=2**4 # Potens med grunntall 2 og eksponent 4, b=16
c=9//5 # Heiltallsdivisjon, c=1
d=9%5 # Modulo 9 av 5, d=4

print(b , c , d) # Skriver ut verdiane til variablane b,c og d

# Datatypar
type(a) # int, som betyr at det er eit heiltal
e=2.71828 # float, flyttal med eit maks antall desimalar
print(2/3) # eksempel på korleis python behandlar divisjon med uendelig mange desimalar
type(True) # bool, bolsk verdi
type("Hello World!") # str, string som betyr ein streng med tegn.

i=int(input("Skriv inn eit tal:")) #Les inn input fra brukaren og endrar datatype til int

print("Du la inn verdien: " , i) # Skriver ut tilbakemelding til brukaren