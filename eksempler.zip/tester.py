# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 12:27:02 2019

@author: emithun
"""

a=5
b=int(input("Skriv inn eit tal: "))

if a<b:
    print(a , "er mindre enn" , b)
    print("Denne linja blir også printa ut")
elif a==b:
    print("a er lik b")
else:
    print("a er større enn b")






