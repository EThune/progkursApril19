# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 10:38:04 2019

@author: emithun
"""

a=[1,2,3,6,9] #Liste med 5 element
b=[2,"Tekst",5.,True] #Liste med 4 element

print(type(b[-1])) # Skriv ut typen på siste element

print(b[0]) # Skriver ut første element i lista

from pylab import * # Hentar biblioteket pylab

arr=linspace(-5,5,11) # Lagar eit array, sjå utskrift for verdiar.
print(arr)

ran=range(1,11) # Lagar eit array.
for i in ran:
    print(i)
    
zer=zeros(10) # Array med 0-arar
print(zer)